<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DTPengadaan extends Model
{
    protected $table = 'dtpengadaan';
    public $timestamps = false;
}
